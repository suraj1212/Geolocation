<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width">
<meta charset="utf-8">
<title>Geolocation</title>
 

</head>

 <style>
 
    #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
	
  </style>
  
  <script>
  function initMap(){
      x = navigator.geolocation;
	  x.getCurrentPosition(success, error);
	   
  function success(position){
		     
	 var mylat = position.coords.latitude;
	 var mylong = position.coords.longitude;
			 
	 var coords = new google.maps.LatLng(mylat,mylong);
		
	 var mapOptions = {
			  zoom:16,
			  center:coords,
			  mapTypeId:google.maps.MapTypeId.ROADMAP 
			   
		   };
			   
	  var map = new google.maps.Map(document.getElementById("map"),mapOptions) ;  
			
			
	  var marker = new google.maps.Marker({
			  map:map,
			  position: coords,
			  draggable:true,
			  title:" You are here"
			   
			   });
			   
	 var searchBox = new google.maps.places.searchBox(document.getElementById("searchbox"));	
	 
	 google.maps.addEventListener(searchBox , 'place_changed', function(){
		 
		var places = searchBox.getPlaces();
		
		
		var bounds = new google.maps.LatLngBounds();
		
		var i,place;
		
		for(i=0; place=places[i];i++){
			console.log(place.geometry.location);
			
			bounds.extend(place.geometry.location);
			marker.setPosition(place.geometry.location);
			
			
			}
		
		map.fitBounds(bounds);
		map.setZoom(16);
		 });	   
		   
		   
    }
		   
		   
  function error(){
		
			alert("Not working")
			
			} 
			
			
}
    
    
</script>


<body>
     <input type="text" id="searchbox" placeholder="Serach places" size="50">
   <div id="map">
     
   </div>
     
   <div id="lat"></div>
   <div id="long"></div>
   

   
   
   
   
   
   
   
   
   
   
   
   <script src="jquery-3.2.1.min.js"></script>
   <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCChqwwBT2_NIPY0Nx9JuiiBAhzujPGTvA&callback=initMap"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCChqwwBT2_NIPY0Nx9JuiiBAhzujPGTvA&libraries=places&callback=initMap"></script>
</body>
</html>